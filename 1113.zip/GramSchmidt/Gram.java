import java.util.ArrayList;

public class Gram {
  
  ArrayList<Vector> initialbasis;
  ArrayList<Vector> projvectors;
  int currentVectorInBasis;
  int nextVectorToSubtract;
  boolean hasFinished = false;
  float currentTime;
  Vector holderFrom;
  Vector holderTo;
  double dt = 0.005;
  boolean projectstate = false;
  boolean scalestate = false;
  
  int[] untransformedColor = {255, 255, 255};
  int[] transformedNonActiveColor = {0, 255, 0};
  int[] activeColor = {255, 0, 0};
  int[] projectedOnColor = {0, 0, 255};
  
   int[] pOnC = {255, 255, 0};
   int[] pOffC = {0, 0, 255};
  
  public Gram(ArrayList<Vector> initialbasis) {
    this.initialbasis = initialbasis;
    for (int i = 0; i < initialbasis.size(); i++) {
      initialbasis.get(i).setColor( untransformedColor );
      System.out.println(initialbasis.get(i).get(0));
    }
    currentTime = -1;
    currentVectorInBasis = 0;
    nextVectorToSubtract = 0;
    projvectors = new ArrayList<Vector>();
    projvectors.add(new Vector(0, 0, 0));
    projvectors.add(new Vector(0,0,0));
  }
  
  
  public void nextStep() {
    if (currentVectorInBasis < initialbasis.size()) {
    System.out.println(currentTime);
    if (currentTime  <= -1) {
      scalestate = false;
      projectstate = false;
      currentTime = 0;
      if (currentVectorInBasis >= initialbasis.size()) {
        hasFinished = true;
      } else if (nextVectorToSubtract < currentVectorInBasis) {
          System.out.println("project off entererd");
          projectstate = true;
         if(nextVectorToSubtract >= 1) {
         initialbasis.get(nextVectorToSubtract-1).setColor( transformedNonActiveColor);
         }
         initialbasis.get(currentVectorInBasis).setColor(activeColor);
         initialbasis.get(nextVectorToSubtract).setColor(projectedOnColor);
         Vector changeTo = Vector.projectOff(initialbasis.get(currentVectorInBasis), initialbasis.get(nextVectorToSubtract));
         holderFrom = Vector.copy(initialbasis.get(currentVectorInBasis));
         holderTo = changeTo;
  
         nextVectorToSubtract++;
         System.out.println("project off exited");
       } else if (nextVectorToSubtract == currentVectorInBasis) {
          System.out.println("scale entered");
          scalestate = true;
         if(nextVectorToSubtract >= 1) {
         initialbasis.get(nextVectorToSubtract-1).setColor(transformedNonActiveColor);
         }
         Vector changeTo = Vector.normalize(initialbasis.get(currentVectorInBasis));
         holderFrom = Vector.copy(initialbasis.get(currentVectorInBasis));
         holderTo = changeTo;
         nextVectorToSubtract++;
                   System.out.println("scale exited");
       } else {
         System.out.println("next vector move entered");
         initialbasis.get(currentVectorInBasis).setColor(transformedNonActiveColor);
         currentVectorInBasis++;
         nextVectorToSubtract = 0;
         System.out.println("next vector move exited");
         currentTime = -2;
       } 
    } else {
  //    System.out.println("interpolation entered");     
      
      for (int i = 0; i < initialbasis.get(currentVectorInBasis).length; i++) {
   //     System.out.println(initialbasis.get(currentVectorInBasis).get(i)); 
   //     System.out.println("grape");
      }
   //   System.out.println(initialbasis.get(0).get(0));
   //   System.out.println("help");
      initialbasis.set(currentVectorInBasis, Vector.interpolate(holderFrom, holderTo, currentTime));
     initialbasis.get(currentVectorInBasis).setColor(activeColor);
      currentTime = currentTime + (float) dt;
      
      if (projectstate) {
        Vector pOn = Vector.projectOn(initialbasis.get(currentVectorInBasis), holderTo);
        pOn.setColor(pOnC);
        Vector pOff = Vector.projectOff(initialbasis.get(currentVectorInBasis), holderTo);
        pOff.setColor(pOffC);
        projvectors.set(0, pOn);
        projvectors.set(1, pOff);
      }

      if(Vector.norm(initialbasis.get(currentVectorInBasis)) < 0.01) {
        currentTime = -2;
        initialbasis.remove(currentVectorInBasis);
        currentVectorInBasis--;
      }

      if (currentTime >= 1) {
       currentTime = -2; 
      }
      //  System.out.println("interpolation exited");
    }
    }
  } 
}
