public class Vector {
 
  float x;
  float y;
  float z;
  
  boolean twod;
  
  float ox;
  float oy;
  float oz;
  
  float red;
  float green;
  float blue;
  float opacity;
  
  public Vector(float x, float y) {
    this(x, y, 0);
    twod = true;
  }
  
  public Vector(float x, float y, float z) {
    this.x = x;
    this.y = y;
    this.z = z;
    twod = false;
    red = 255;
    green = 255;
    blue = 255;
    opacity = 255;
  }
  
  public static Vector add(Vector v1, Vector v2) {
    float x = v1.x + v2.x;
    float y = v1.y + v2.y;
    float z = v1.z + v2.z;
    Vector output;
    if (v1.twod) {
       output = new Vector(x, y);
    } else {
     output = new Vector(x, y, z); 
    }
    return output;
  }
  
    public static Vector sub(Vector v1, Vector v2) {
    float x = v1.x - v2.x;
    float y = v1.y - v2.y;
    float z = v1.z - v2.z;
    Vector output;
    if (v1.twod) {
       output = new Vector(x, y);
    } else {
     output = new Vector(x, y, z); 
    }
    return output;
  }
  
  public static Vector mult(float scalar, Vector v2) {
    float x = scalar*v2.x;
    float y = scalar*v2.y;
    float z = scalar*v2.z;
    Vector output;
    if (v2.twod) {
       output = new Vector(x, y);
    } else {
     output = new Vector(x, y, z); 
    }
    return output;
  }
  
   public static Vector div(float scalar, Vector v2) {
    float x = v2.x/scalar;
    float y = v2.y/scalar;
    float z = v2.z/scalar;
    Vector output;
    if (v2.twod) {
       output = new Vector(x, y);
    } else {
     output = new Vector(x, y, z); 
    }
    return output;
  }
  
  
}
