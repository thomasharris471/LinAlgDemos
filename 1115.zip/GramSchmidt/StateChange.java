public class StateChange {
  
  public Vector initialState;
  public Vector finalState;
  
  public StateChange(Vector in, Vector out) {
    initialState = in;
    finalState = out;
  }
  
}
