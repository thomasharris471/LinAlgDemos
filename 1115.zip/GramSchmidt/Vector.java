import java.util.ArrayList;

public class Vector {
  
  public float[] values;
  public int length;
  public int red;
  public int green;
  public int blue;
  public float opacity = 255;
  
  public Vector(float x, float y) {
    values = new float[2];
    values[0] = x;
    values[1] = y;
    length = values.length;
  }
  
  public Vector(float x, float y, float z) {
    values = new float[3];
    values[0] = x;
    values[1] = y;
    values[2] = z;
    length = values.length;
  }
  
  public Vector(float[] entries) {
    values = new float[entries.length];
    for (int i = 0; i < entries.length; i++) {
      values[i] = entries[i]; 
    }
    length = values.length;
  }
  
  public void setColor(int[] array) {
    red = array[0];
    green = array[1];
    blue = array[2];
  }
 
  
  public float get(int i) {
    return values[i]; 
  }
  
  public static float dot(Vector v1, Vector v2) {
    float sum = 0;
    for (int i = 0; i < v1.length; i++) {
       sum = sum + v1.get(i)*v2.get(i);
    }
    return sum;
  }
  
  public static float norm(Vector v1) {
    double normsquared = (double) Vector.dot(v1, v1);
    return (float) Math.sqrt(normsquared); 
  }
  
  public static Vector mult(float scalar, Vector v) {
    float[] values = new float[v.length];
    for (int i = 0; i < v.length; i++) {
      values[i] = scalar*v.get(i); 
    }
    return new Vector(values);
  }
  
  public static Vector normalize(Vector v1) {
    return Vector.mult(1/Vector.norm(v1), v1);
  }
  
  public static Vector projectOff(Vector v1, Vector v2) {
    float scale = Vector.dot(v1, v2)/Vector.dot(v2, v2);
    float[] values = new float[v1.length];
    for (int i = 0; i < v1.length; i++) {
      values[i] = v1.get(i) - scale*v2.get(i); 
    }
    return new Vector(values);
  }
  
  public static Vector projectOn(Vector v1, Vector v2) {
    float scale = Vector.dot(v1, v2)/Vector.dot(v2, v2);
    float[] values = new float[v1.length];
    for (int i = 0; i < v1.length; i++) {
      values[i] = scale*v2.get(i); 
    }
    return new Vector(values);
  }
  
   public static Vector projectOnSpace(Vector v1, ArrayList<Vector> space) {
    float[] scales = new float[space.size()];
    float[] values = new float[space.get(0).length];
    for (int i = 0; i < scales.length; i++) {
      scales[i] = Vector.dot(v1, space.get(i))/Vector.dot(space.get(i), space.get(i)); 
    }
    for (int i = 0; i < v1.length; i++) {  
      values[i] = 0;
      for (int j = 0; j < space.size(); j++) {
        values[i] = values[i] + scales[j]*space.get(j).get(i);
      }
    }
    return new Vector(values);
  }
  
  public static Vector projectOffSpace(Vector v1, ArrayList<Vector> space) {
    float[] scales = new float[space.size()];
    float[] values = new float[space.get(0).length];
    for (int i = 0; i < scales.length; i++) {
      scales[i] = Vector.dot(v1, space.get(i))/Vector.dot(space.get(i), space.get(i)); 
    }
    for (int i = 0; i < v1.length; i++) {  
      values[i] = v1.get(i);
      for (int j = 0; j < space.size(); j++) {
        values[i] = values[i] - scales[j]*space.get(j).get(i);
      }
    }
    return new Vector(values);
  }
  
   public static Vector difference(Vector v1, Vector v2) {
    float[] values = new float[v1.length];
    for (int i = 0; i < values.length; i++) {
      values[i] = v1.get(i) - v2.get(i); 
    }
    return new Vector(values);
  }
  
  public static Vector interpolate(Vector v1, Vector v2, float time) {
      float[] values = new float[v1.length];
      for (int i = 0; i < v1.length; i++) {
        values[i] = v1.get(i) + (float) Math.sin(time*Math.PI/2)*(v2.get(i) - v1.get(i)); 
      }
      return new Vector(values);
  }
  
    public static Vector copy(Vector v1) {
      float[] values = new float[v1.length];
      for (int i = 0; i < v1.length; i++) {
        values[i] = v1.get(i); 
      }
      return new Vector(values);
  }
  

}
