import java.util.ArrayList;


public class Ball {
 
  public Vector position;
  public Vector velocity;
  public Vector nextVelocity;
  
  public ArrayList<Vector> collisions;
  
  public float radius;
  public float mass;
  public int red;
  public int green;
  public int blue;
  
  public boolean possessed;
  
  public boolean finite;
  public int lifespan;
  public boolean isphoton;
  
  public boolean wallstruck;
      
  public Ball(Vector position, Vector velocity, float radius, float mass) {
    this.position = new Vector(position);
    this.velocity = new Vector(velocity);
    this.nextVelocity = new Vector(velocity);
    
    collisions = new ArrayList<Vector>();
    
    this.radius = radius;
    this.mass = mass;
    
    red = 255;
    green = 255;
    blue = 255;
    
   possessed = false;
   finite = false;
   lifespan = 1000;
   isphoton = false;
    wallstruck = false;
  }
  
  public void updatePosition(Vector v) {
    Vector.copy(position, v);
  }
  
  public void updateVelocity(Vector v) {
    Vector.copy(velocity, v);
  }
    
  public void updateNextVelocity(Vector v) {
    Vector.copy(nextVelocity, v); 
  }

  
  
}
