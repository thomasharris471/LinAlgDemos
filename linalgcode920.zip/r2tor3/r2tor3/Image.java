import java.util.ArrayList;
public class Image {
  
  ArrayList<Pixel> Pixels;

  public Image(ArrayList<Pixel> pixelss) {
    Pixels = pixelss;
  }
  
  public void transform(float[][] matrix) {
    for (Pixel p : Pixels) {
       float xholder = p.x;
       float yholder = p.y;
       float zholder = p.z;
       p.x = matrix[0][0]*xholder + matrix[0][1]*yholder;
       p.y = matrix[1][0]*xholder + matrix[1][1]*yholder;
       p.z = matrix[2][0]*xholder + matrix[2][1]*yholder;
    }
  }

}
