public class Pixel {
  
  public float x;
  public float y;
  public float red;
  public float blue;
  public float green;
  public float trans;
  
  public Pixel(float xLocation, float yLocation, float red, float green, float blue) {
     this.x = xLocation;
     this.y = yLocation;
     this.red = red;
     this.blue = blue;
     this.green = green;
     trans = 200;
  }
  
}
