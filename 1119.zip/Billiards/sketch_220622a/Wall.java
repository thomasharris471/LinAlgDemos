public class Wall {
 
  public Vector leftSide;
  public Vector rightSide;
  
  public boolean collided;
  
  public Wall(Vector leftSide, Vector rightSide) {
    this.leftSide = new Vector(leftSide.x, leftSide.y);
    this.rightSide = new Vector(rightSide.x, rightSide.y);
    collided = false;
  }
  
  public Wall(float xLeft, float yLeft, float xRight, float yRight) {
    this.leftSide = new Vector(xLeft, yLeft);
    this.rightSide = new Vector(xRight, yRight);
    collided = false;
  }
}
