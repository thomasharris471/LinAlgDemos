import java.util.ArrayList;

public class SparseImage {
  
  ArrayList<Pixel> Pixels;
  

  public SparseImage(ArrayList<Pixel> pixelss) {
    Pixels = pixelss;
  }

  
}
