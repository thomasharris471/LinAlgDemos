public class MassSpring {
  
  Wall bracket;
  Wall detector;
  
  float m = 1;
  float b = 2;
  float k = 4;
  
  float initialDisplacement = 100;
  float initialVelocity = 0;
  
  float previousDisplacement;
  float currentDisplacement;
  
  float nextStateprevDisplacement;
  float nextStateCurrentDisplacement;
  
  public MassSpring() {
    
  }
  
  public void setNextState(float dt, float f) {
    float denominator = b*dt + 2*m;
    float num1 = (-2*dt*dt*k+4*m)*currentDisplacement;
    float num2 = (b*dt - 2*m)*previousDisplacement;
    float num3 = 2*dt*dt*f;
    nextStateprevDisplacement = currentDisplacement;
    nextStateCurrentDisplacement = (num1 + num2 + num3)/denominator;  
  }
  
  public void updateState() {
     previousDisplacement = nextStateprevDisplacement;
     
  }
  
  
}
