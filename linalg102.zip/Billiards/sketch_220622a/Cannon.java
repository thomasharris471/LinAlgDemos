import java.util.ArrayList;


public class Cannon {
  
  public Vector position;
  public float angle;
  float cooldowntime;
  public ArrayList<Ball> balls;
  public Ball ball;
  public boolean fired;
  
  public Cannon() {
    
   angle = 0;
   position = new Vector(250, 300);
   cooldowntime = 0;
   fired = false;
  }

  public void fire() {
    if (cooldowntime <= 0) {
      fired = true;
      balls = new ArrayList<Ball>();
      float vel = 1000;
      double shots = 100;
      for (int i = -1; i < 1; i++) {
       // balls.add(new Ball(position, new Vector((float) (200*Math.cos(angle + 1/(10*shots)*i-1/(20*shots))), (float) (200*Math.sin(angle+1/(10*shots)*i-1/(20*shots)))), 5, (float) 0.001));
       balls.add(new Ball(new Vector((float) (position.x- 5*i*Math.sin(angle)), (float) (position.y + (float) 5*i*Math.cos(angle))), new Vector((float) (vel*Math.cos(angle)), (float) (vel*Math.sin(angle))), 5, (float) 0.001));
      }
     // ball = new Ball(position, new Vector((float) (200*Math.cos(angle)), (float) (200*Math.sin(angle))), 5, (float) 0.1);
      for (Ball b : balls) {
        //b.finite = true;
        b.isphoton= true;
        b.blue = 0;
        b.radius=5;
      }
    //  ball.finite = true;
    //  ball.isphoton = true;
      cooldowntime = 10;
    }
  }
  

  public boolean checkIfFired() {
     return fired;
  }
  
  public Ball getBall() {
    fired = false;
    return ball; 
  }
  
  public ArrayList<Ball> getBalls() {
    fired = false;
    return balls; 
  }
  
  public void cooldown() {
    if (cooldowntime > -1) {
      cooldowntime = cooldowntime - 1;
    }
  }
  
  public void rotate(float ang) {
    angle = angle + ang;
  }
  
  
}
