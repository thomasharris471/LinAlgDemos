public class Pendulum {
  
  double m1;
  double m2;
  double l1;
  double l2;
  
  double t1;
  double t2;
  
  double tp1;
  double tp2;
  
  double g;
  
  float red=255;
  float green=255;
  float blue=255;
  
  float sw = 3;
  
 
  public Pendulum() {
    l1 = 2;
    l2 = 2;
    g = 10;
    m1 = 20;
    m2 = 20;
    t1 = Math.random()*2*Math.PI - Math.PI;
    t2 = Math.random()*2*Math.PI - Math.PI;
    tp1 = 0;
    tp2 = 0;
  }
  
  public float x1() {
    return (float) (l1*Math.sin(t1)); 
  }
  
  public float x2() {
    return (float) (l1*Math.sin(t1) + l2*Math.sin(t2)); 
  }
  
  public float y1() {
    return (float) (-l1*Math.cos(t1)); 
  }
  
  public float y2() {
    return (float) (-l1*Math.cos(t1) - l2*Math.cos(t2)); 
  }
  
  public double tpp1(double t1, double t2, double tp1, double tp2) {
     double num1 = -g*(2*m1+m2)*Math.sin(t1);
     double num2 = -m2*g*Math.sin(t1 - 2*t2);
     double num3 = -2*Math.sin(t1 - t2)*m2*(tp2*tp2*l2 + tp1*tp1*l1*Math.cos(t1-t2));
     double den = l1*(2*m1 + m2 - m2*Math.cos(2*t1-2*t2));
     
     return (num1+num2+num3)/den;
  }
  
    public double tpp2(double t1, double t2, double tp1, double tp2) {
     double coeff1=2*Math.sin(t1-t2);
     double num2 = tp1*tp1*l1*(m1+m2);
     double num3 = g*(m1+m2)*Math.cos(t1);
     double num4 = tp2*tp2*l2*m2*Math.cos(t1-t2);
     double den = l2*(2*m1 + m2 - m2*Math.cos(2*t1-2*t2));
     
     return coeff1*(num2+num3+num4)/den;
  }
  
  public void update(double dt) {
    double t1next = tpp1(t1, t2, tp1, tp2)*dt*dt + tp1*dt + t1;
    double t2next = tpp2(t1, t2, tp1, tp2)*dt*dt + tp2*dt + t2;
    tp1 = (t1next-t1)/dt;
    tp2 = (t2next-t2)/dt;
    t1 = t1next;
    t2 = t2next;
    
    
    
  }
  
}
