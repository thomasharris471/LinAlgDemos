public class ComplexNumber {
 
  public double amplitude;
  public double phase;
  
  public double red;
  public double green;
  public double blue;
  
  public ComplexNumber(double a, double p) {
    amplitude = a;
    phase = p;
  }
  
}
