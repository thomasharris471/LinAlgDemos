public class Oscillators {
  public double m;
  public double b;
  public double k;
  
  public double y = 0;
  public double prevY = 0;
  
  public double holder;
  
  public double dt;
  
  public void update(double f) {
    holder = y;
    y = ((b*dt - 2*m)*prevY + 2*dt*dt*(f-k*y) + 4*m*y)/(b*dt+2*m);
    prevY = holder;
  //  System.out.println(y);
  }
  

  
}
