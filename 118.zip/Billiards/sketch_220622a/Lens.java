import java.util.ArrayList;

public class Lens {
  
  public ArrayList<Wall> walls;
  public Vector orientation;
  public float refract;
  
  public Lens() {
     walls = new ArrayList<Wall>();
    
    Wall wall1 = new Wall(200, 0, 200, 600);
    walls.add(wall1);
    orientation = new Vector(1, 0);
    refract = (float) 0.5;
  }
  
  

  

  
}
  
