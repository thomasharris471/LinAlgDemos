import shiffman.box2d.*;
import org.jbox2d.collision.shapes.*;
import org.jbox2d.common.*;
import org.jbox2d.dynamics.*;

public class Box {
 
  Body body;
  
  float x, y;
  float w, h;
  
  public Box(float x_, float y_) {
      
  }
  
  void makeBody(Vec2 center, float w_, float h_) {
    
  }
  
  
}
