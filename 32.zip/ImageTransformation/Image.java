import java.util.ArrayList;

public class Image {
  
  ArrayList<Pixel> Pixels;

  public Image(ArrayList<Pixel> pixelss) {
    Pixels = pixelss;
  }
  
  public void transform(float[][] matrix) {
    for (Pixel p : Pixels) {
       float xholder = p.x;
       float yholder = p.y;
       p.x = matrix[0][0]*xholder + matrix[0][1]*yholder;
       p.y = matrix[1][0]*xholder + matrix[1][1]*yholder;
       
    }
  }
  
  public  ArrayList<Pixel> mutated(float[][] matrix) {
    ArrayList<Pixel> mut = new ArrayList<Pixel>();
    for (Pixel p : Pixels) {
      Pixel mp = new Pixel(0,0,0,0,0);
      mp.red = p.red;
      mp.green = p.green;
      mp.blue = p.blue;
      float xholder = p.x;
       float yholder = p.y;
       mp.x = matrix[0][0]*xholder + matrix[0][1]*yholder;
       mp.y = matrix[1][0]*xholder + matrix[1][1]*yholder;
       mut.add(mp);
      
    }
    return mut;
  }
  
    public static Image grid() {
    int step = 20;
    int r = 0;
    int g = 0;
    int b = 0;
    ArrayList<Pixel> pixs = new ArrayList<Pixel>();
    for (int i = -300; i < 300; i++) {
      for (int j = -15; j < 15; j++) {
        if (i < -200 || i > 200 || j < -10 || j > 10) {
          r = 255;
          g = 0;
          b = 0;
        } else {
          r = 0;
          g = 255;
          b = 0;
        }
        Pixel p = new Pixel(i, j*step, r, g, b);
        pixs.add(p);
        p = new Pixel(j*step, i, r, g, b);
        pixs.add(p);
      }
    }
    return new Image(pixs);
  }
  

}
