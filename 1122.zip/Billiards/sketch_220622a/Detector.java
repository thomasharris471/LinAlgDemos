import java.util.ArrayList;

public class Detector {
  
  public ArrayList<ArrayList<Wall>> fronthistory;
   public ArrayList<ArrayList<Wall>> backhistory;
  public ArrayList<Wall> walls;
  
  public ArrayList<Wall> backwalls;
  public ArrayList<Wall> frontwalls;
  
  public Detector() {
     walls = new ArrayList<Wall>();
     backwalls = new ArrayList<Wall>();
     frontwalls = new ArrayList<Wall>();
     
    // fronthistory = 
    
    Wall wall1 = new Wall(400, 400, 400, 380);
    Wall wall2 = new Wall(400, 380, 420, 360);
    Wall wall3 = new Wall(420, 360, 440, 360);
    Wall wall4 = new Wall(440, 360, 460, 380);
    Wall wall5 = new Wall(460, 380, 460, 400);
    
    Wall wall6 = new Wall(405, 400, 405, 380);
    Wall wall7 = new Wall(405, 380, 420, 365);
    Wall wall8 = new Wall(420, 365, 440, 365);
    Wall wall9 = new Wall(440, 365, 455, 380);
    Wall wall10 = new Wall(455, 380, 455, 400);
    
    

   
    walls.add(wall1);
    walls.add(wall2);
    walls.add(wall3);
    walls.add(wall4);
    walls.add(wall5);
    walls.add(wall6);
    walls.add(wall7);
    walls.add(wall8);
    walls.add(wall9);
    walls.add(wall10);
    
    backwalls.add(wall1);
    backwalls.add(wall2);
    backwalls.add(wall3);
    backwalls.add(wall4);
    backwalls.add(wall5);
    
    frontwalls.add(wall6);
    frontwalls.add(wall7);
    frontwalls.add(wall8);
    frontwalls.add(wall9);
    frontwalls.add(wall10);

  }
  
}
