import java.util.ArrayList;


public class Master {
 
  public Geometry table;
  public ArrayList<Ball> balls;
  public Detector detector;
  public Cannon cannon;
  public Lens lens;
  
  public float refractionindex = (float) 0.7;
  
  public float gravityconstant = 10990;
  
  
//run find next Velocities first, then run update Velocities, then run updatePositions
  
  public Master(ArrayList<Ball> balls, Geometry table) {
    this.balls = balls;
    this.table = table;
    detector = new Detector();
    cannon = new Cannon();
    lens = new Lens();
  }
  
  public Master() {
    this(new ArrayList<Ball>(), new Geometry());  
  }
  
  public void iterate(float dt) {
     this.findNextVelocities(dt);
     updateDetector();
    
     this.updateVelocities();
      lenscollision();
     this.updatePositions(dt);
 
     getTotalKineticEnergy();
     getexpectedVelocity();
              addCannonBalls();
              cleanballs();

  }
  
 
   public void lenscollision() {
    ArrayList<Ball> toRemove = new ArrayList<Ball>();
    ArrayList<Ball> toAdd = new ArrayList<Ball>();
          Wall w= lens.walls.get(0);
          Vector orientation = lens.orientation;
          float refract = lens.refract;
    for (Ball b : balls) {
      if (detectLensCollision(b, w)) {
        
      }
      
    }
    for (Ball b : toRemove) {
      balls.remove(b); 
    }
    for (Ball b : toAdd) {
      balls.add(b); 
    }
  }
  

  
  
   public boolean detectLensCollision(Ball b, Wall w) {
     boolean collided = false;
    Vector change = new Vector(0,0);
    Vector v0 = w.leftSide;
    Vector v1 = w.rightSide;
    Vector w1minusv0 = Vector.subtract(b.position, v0);
    Vector v1minusv0 = Vector.subtract(v1, v0);
    Vector w1minusv1 = Vector.subtract(b.position, v1);
    Vector v0minusv1 = Vector.subtract(v0, v1);
    float normed = Vector.norm(v1minusv0);
    Vector scaledv1minusv0 = Vector.multiply((float) 1.0/normed, v1minusv0);
   
    
    
    float minDistance = (float) (Math.sqrt((float) Math.pow(Vector.norm(w1minusv0), 2) - (float) Math.pow(Vector.innerproduct(w1minusv0, scaledv1minusv0), 2)));
    
    if (Vector.innerproduct(w1minusv0, v1minusv0) <= 0) {
      minDistance =  Vector.norm(w1minusv0); 
    }
    if (Vector.innerproduct(w1minusv1, v0minusv1) <= 0) {
      minDistance = Vector.norm(w1minusv1); 
    }
    
    if (minDistance < b.radius) {
      Vector intersectionDirection = Vector.subtract(w1minusv0  , Vector.multiply(Vector.innerproduct(w1minusv0, scaledv1minusv0), scaledv1minusv0));
      Vector scaledIntersection = Vector.normalized(intersectionDirection);
      Vector currentVelocity = b.velocity;
      float scalar = -2;
      if (Vector.innerproduct(currentVelocity, scaledIntersection) >= 0) {
        scalar = 0;  
      }
      collided = true;
    }
    return collided;  
  }
  
  
  
  public void cleanballs() {
    ArrayList<Ball> remove = new ArrayList<Ball>();
    for (Ball b : balls) {
      if (b.finite) {
        b.lifespan--;
        if(b.lifespan < 0) {
          remove.add(b);
        }
      }
    }
    for (Ball b : remove) {
       balls.remove(b); 
    }
  }
  
  public void addCannonBall() {
    if (cannon.checkIfFired()) {
      balls.add(cannon.getBall());
     // System.out.println("apple");
    }
    cannon.cooldown();
  }
  
  public void addCannonBalls() {
    if (cannon.checkIfFired()) {
      for (Ball b : cannon.getBalls()) {
        balls.add(b);
        System.out.println("apple");
      }
    }
    cannon.cooldown();
  }
  
  public void updatePositions(float dt) {
    for (Ball b : balls) {
      float scalar = 1;
      float distance1 = (float) Math.sqrt((b.position.x-300)*(b.position.x-300) + (b.position.y - 300)*(b.position.y-300));
      float distance2 = (float) Math.sqrt((b.position.x-500)*(b.position.x-500) + (b.position.y - 300)*(b.position.y-300));
      if (distance1 < 200 && distance2 < 200) {
      //  scalar = (float) 0.2; 
      }
      Vector displacement = Vector.multiply(scalar*dt, b.velocity);
      Vector newPosition = Vector.add(b.position, displacement);
      b.updatePosition(newPosition);
      b.wallstruck = false;
    }
  }
  
  public void getTotalKineticEnergy() {
    float current = 0;
    for (Ball b : balls) {
      float m = b.mass;
      float v = Vector.norm(b.velocity);
      current = current + m*v*v;
    }
   //out.println(current);
  }
  
  public void getexpectedVelocity() {
    float px = 0;
    float py= 0;
    float totalMass = 0;
    for (Ball b : balls) {
       totalMass = totalMass + b.mass;
       px = px + b.velocity.x*b.mass;
       py = py + b.velocity.y*b.mass;
    }
    float vx = px/totalMass;
    float vy = py/totalMass;
  }
  
  public void getVelocitySTDDEV() {
   
  }
  
  public void updateDetector() {
    for (Wall w : detector.walls) {
      w.collided = false;
      for (Ball b : balls) {
        detecorCollisions(b, w);
      }
    }
  }
  
  public void detecorCollisions(Ball b, Wall w) {
    Vector change = new Vector(0,0);
    Vector v0 = w.leftSide;
    Vector v1 = w.rightSide;
    Vector w1minusv0 = Vector.subtract(b.position, v0);
    Vector v1minusv0 = Vector.subtract(v1, v0);
    Vector w1minusv1 = Vector.subtract(b.position, v1);
    Vector v0minusv1 = Vector.subtract(v0, v1);
    float normed = Vector.norm(v1minusv0);
    Vector scaledv1minusv0 = Vector.multiply((float) 1.0/normed, v1minusv0);
   
    
    
    float minDistance = (float) (Math.sqrt((float) Math.pow(Vector.norm(w1minusv0), 2) - (float) Math.pow(Vector.innerproduct(w1minusv0, scaledv1minusv0), 2)));
    
    if (Vector.innerproduct(w1minusv0, v1minusv0) <= 0) {
      minDistance =  Vector.norm(w1minusv0); 
    }
    if (Vector.innerproduct(w1minusv1, v0minusv1) <= 0) {
      minDistance = Vector.norm(w1minusv1); 
    }
    
    if (minDistance < b.radius) {
      Vector intersectionDirection = Vector.subtract(w1minusv0  , Vector.multiply(Vector.innerproduct(w1minusv0, scaledv1minusv0), scaledv1minusv0));
      Vector scaledIntersection = Vector.normalized(intersectionDirection);
      Vector currentVelocity = b.velocity;
      float scalar = -2;
      if (Vector.innerproduct(currentVelocity, scaledIntersection) >= 0) {
        scalar = 0;  
      }
      //change = Vector.multiply(scalar, Vector.project(currentVelocity, scaledIntersection));
      w.collided = true;
    } 
    b.collisions.add(change);
    
    
  }
  
  
  public void updateVelocities() {
    for (Ball b : balls) {
       b.updateVelocity(b.nextVelocity);
    }
  }
  

  public void findNextVelocities(float dt) {
    for (Ball currentBall : balls) {
      if (!currentBall.possessed) { 
        Vector changeInVelocity = new Vector(0,0);
        currentBall.collisions.clear();
        for (Ball otherBall : balls) {
          if (otherBall != currentBall && !otherBall.possessed) {
              changeInVelocity = Vector.add(changeInVelocity, velocityOfFirstBallAfterCollision(currentBall, otherBall));
              //gravity???
               changeInVelocity = Vector.add(changeInVelocity, velocityOfFirstBallAfterGravity(dt, currentBall, otherBall));
          }
        }
        for (Wall wall : table.walls) {
            changeInVelocity = Vector.add(changeInVelocity, velocityAfterWallCollision(currentBall, wall));
        }
        Vector nextVelocity = Vector.add(currentBall.velocity, changeInVelocity);
        currentBall.updateNextVelocity(nextVelocity);
      }
      
      //gravity
      
    }
  }
  
  public Vector velocityOfFirstBallAfterGravity(float dt, Ball b1, Ball b2) {
    Vector change = new Vector(0,0);
    
    float distance = Vector.norm(Vector.subtract(b1.position, b2.position));
    System.out.println(distance);
    Vector ball2Direction = Vector.normalized(Vector.subtract(b2.position, b1.position));
    float m2 = b2.mass;
   //float dcomponent = (float) (Math.pow((double) distance, 2)*Math.sin((double) distance/1));
   float dcomponent = (float) (Math.pow((double) distance, 2));
    float xpp = m2*gravityconstant/(dcomponent)*ball2Direction.x;
    float ypp = m2*gravityconstant/(dcomponent)*ball2Direction.y;
    change = new Vector(xpp*dt, ypp*dt);
  
  /*
    if (distance <= (float) (b1.radius + b2.radius)) {
      Vector collisionDirection = Vector.normalized(Vector.subtract(b1.position, b2.position));
      float v1 = Vector.innerproduct(b1.velocity, collisionDirection);
      float v2 = Vector.innerproduct(b2.velocity, collisionDirection);
      float m1 = b1.mass;
      float m2 = b2.mass;
      float w1 = (float) 1*((v1*(m1-m2) + 1*2*m2*v2)/(m1+m2));
      //float w1 = (float) Math.pow(((m1 - m2)*(float) Math.sqrt(Math.abs(v1)) + 2*m2*(float) Math.sqrt(Math.abs(v2))),2)/((m1+m2)*(m1+m2));
      //float w1 = m2*v2/m1;
     // float w1 = v1;
      float deltaV = (float) (w1-v1);
      if (v1 < 0 || v2 > 0) {
        if (!b1.isphoton || !b2.isphoton) {
          change = Vector.multiply(deltaV, collisionDirection);
        }
      }
    }
    */
    b1.collisions.add(change);
    return change;  
  }
  
  
   public Vector velocityAfterWallCollisionLens(Ball b, Wall w) {
    Vector change = new Vector(0,0);
    Vector v0 = w.leftSide;
    Vector v1 = w.rightSide;
    Vector w1minusv0 = Vector.subtract(b.position, v0);
    Vector v1minusv0 = Vector.subtract(v1, v0);
    Vector w1minusv1 = Vector.subtract(b.position, v1);
    Vector v0minusv1 = Vector.subtract(v0, v1);
    float normed = Vector.norm(v1minusv0);
    Vector scaledv1minusv0 = Vector.multiply((float) 1.0/normed, v1minusv0);
   
    
    
    float minDistance = (float) (Math.sqrt((float) Math.pow(Vector.norm(w1minusv0), 2) - (float) Math.pow(Vector.innerproduct(w1minusv0, scaledv1minusv0), 2)));
    
    if (Vector.innerproduct(w1minusv0, v1minusv0) <= 0) {
      minDistance =  Vector.norm(w1minusv0); 
    }
    if (Vector.innerproduct(w1minusv1, v0minusv1) <= 0) {
      minDistance = Vector.norm(w1minusv1); 
    }
    
    if (minDistance < b.radius) {
      Vector intersectionDirection = Vector.subtract(w1minusv0  , Vector.multiply(Vector.innerproduct(w1minusv0, scaledv1minusv0), scaledv1minusv0));
      Vector scaledIntersection = Vector.normalized(intersectionDirection);
      Vector currentVelocity = b.velocity;
      float scalar = -2;
      if (Vector.innerproduct(currentVelocity, scaledIntersection) >= 0) {
        scalar = 0;  
      }
      if (!b.wallstruck) {
        change = Vector.multiply(scalar, Vector.project(currentVelocity, scaledIntersection));
        b.wallstruck = true;
      }
      
    }
    b.collisions.add(change);
    return change;  
  }
  

  
  public Vector velocityOfFirstBallAfterCollision(Ball b1, Ball b2) {
    Vector change = new Vector(0,0);
    
    float distance = Vector.norm(Vector.subtract(b1.position, b2.position));
    if (distance <= (float) (b1.radius + b2.radius)) {
      Vector collisionDirection = Vector.normalized(Vector.subtract(b1.position, b2.position));
      float v1 = Vector.innerproduct(b1.velocity, collisionDirection);
      float v2 = Vector.innerproduct(b2.velocity, collisionDirection);
      float m1 = b1.mass;
      float m2 = b2.mass;
      float w1 = (float) 1*((v1*(m1-m2) + 1*2*m2*v2)/(m1+m2));
      //float w1 = (float) Math.pow(((m1 - m2)*(float) Math.sqrt(Math.abs(v1)) + 2*m2*(float) Math.sqrt(Math.abs(v2))),2)/((m1+m2)*(m1+m2));
      //float w1 = m2*v2/m1;
     // float w1 = v1;
      float deltaV = (float) (w1-v1);
      if (v1 < 0 || v2 > 0) {
        if (!b1.isphoton || !b2.isphoton) {
          change = Vector.multiply(deltaV, collisionDirection);
        }
      }
    }
    b1.collisions.add(change);
    return change;  
  }
  
  public Vector velocityAfterWallCollision(Ball b, Wall w) {
    Vector change = new Vector(0,0);
    Vector v0 = w.leftSide;
    Vector v1 = w.rightSide;
    Vector w1minusv0 = Vector.subtract(b.position, v0);
    Vector v1minusv0 = Vector.subtract(v1, v0);
    Vector w1minusv1 = Vector.subtract(b.position, v1);
    Vector v0minusv1 = Vector.subtract(v0, v1);
    float normed = Vector.norm(v1minusv0);
    Vector scaledv1minusv0 = Vector.multiply((float) 1.0/normed, v1minusv0);
   
    
    
    float minDistance = (float) (Math.sqrt((float) Math.pow(Vector.norm(w1minusv0), 2) - (float) Math.pow(Vector.innerproduct(w1minusv0, scaledv1minusv0), 2)));
    
    if (Vector.innerproduct(w1minusv0, v1minusv0) <= 0) {
      minDistance =  Vector.norm(w1minusv0); 
    }
    if (Vector.innerproduct(w1minusv1, v0minusv1) <= 0) {
      minDistance = Vector.norm(w1minusv1); 
    }
    
    if (minDistance < b.radius) {
      Vector intersectionDirection = Vector.subtract(w1minusv0  , Vector.multiply(Vector.innerproduct(w1minusv0, scaledv1minusv0), scaledv1minusv0));
      Vector scaledIntersection = Vector.normalized(intersectionDirection);
      Vector currentVelocity = b.velocity;
      float scalar = -2;
      if (Vector.innerproduct(currentVelocity, scaledIntersection) >= 0) {
        scalar = 0;  
      }
      change = Vector.multiply(scalar, Vector.project(currentVelocity, scaledIntersection));
    }
    b.collisions.add(change);
    return change;  
  }
  
}
