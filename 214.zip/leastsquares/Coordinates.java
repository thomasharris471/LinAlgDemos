public class Coordinates {

  public float x;
  public float y;
  
  public Coordinates(float x, float y) {
    this.x = x;
    this.y = y;
  }
  
}
