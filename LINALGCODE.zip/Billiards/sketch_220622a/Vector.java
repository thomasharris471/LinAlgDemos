public class Vector {
 
  public float x;
  public float y;
  
  public Vector(float x, float y) {
    this.x = x;
    this.y = y;
  }
  
  public Vector(Vector v) {
    this(v.x, v.y); 
  }
  
  public static Vector add(Vector v1, Vector v2) {
    float x = v1.x + v2.x;
    float y = v1.y + v2.y;
    return new Vector(x, y);
  }
  
  public static Vector multiply(float s, Vector v) {
    float x = s*v.x;
    float y = s*v.y;
    return new Vector(x, y);
  }
  
  public static Vector subtract(Vector v1, Vector v2) {
    return Vector.add(v1, Vector.multiply(-1, v2)); 
  }
   
  public static float innerproduct(Vector v1, Vector v2) {
    return v1.x*v2.x + v1.y*v2.y; 
  } 
  
  public static float norm(Vector v) {
    return (float) Math.sqrt(Vector.innerproduct(v, v)); 
  }
  
  public static Vector normalized(Vector v) {
   float norm = Vector.norm(v);
   return Vector.multiply((float) 1.0/norm, v);
  }
  
  public static Vector project(Vector v, Vector onto) {
     return Vector.multiply(Vector.innerproduct(v, onto), onto);
  }
  
  public static Vector orthogonalproject(Vector v, Vector onto) {
    Vector normed = normalized(onto);
     return Vector.multiply(Vector.innerproduct(v, normed), normed);
  }
  
  public static void copy(Vector copyto, Vector copyfrom) {
    copyto.x = copyfrom.x;
    copyto.y = copyfrom.y;
  }
  
}
