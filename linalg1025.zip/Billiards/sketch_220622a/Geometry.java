import java.util.ArrayList;

public class Geometry {
  
  public ArrayList<Wall> walls;
  
  public Geometry() {
     walls = new ArrayList<Wall>();
    
    Wall wall1 = new Wall(0, 0, 0, 600);
    Wall wall2 = new Wall(0, 600, 800, 600);
    Wall wall3 = new Wall(800, 600, 800, 0);
    Wall wall4 = new Wall(800, 0, 0, 0);
    
    Wall wall5 = new Wall(680, 600, 680, 480);
    Wall wall6 = new Wall(680, 480, 800, 480);
   
  //  walls.add(wall1);
  //  walls.add(wall2);
   // walls.add(wall3);
   // walls.add(wall4);
  //  walls.add(wall5);
   // walls.add(wall6);
    
    for (int i = 0; i < 8; i++) {
     // walls.add(new Wall(400, 80*i, 400, 80*i + 40)); 
    }
    
    int wallsize = 10;
    for (int i = 0; i <100; i++) {
      int rand = (int)(20*Math.random()-10);
   //   walls.add(new Wall(800-wallsize*2*i, 600, 800-wallsize*(2*i+1)+rand, 600-wallsize));
    //  walls.add(new Wall(800-wallsize*(2*i+1)+rand, 600-wallsize, 800-wallsize*(2*i+2), 600));
    }
    
  }
  
  public Geometry(ArrayList<Wall> walls) {
    this.walls = walls; 
  }
  
  public static Geometry lens() {
    Wall ws = new Wall(200, 0, 200, 800);
    ArrayList<Wall> w = new ArrayList<Wall>();
    w.add(ws);
    return new Geometry(w);
  }
  

  

  
}
  
  
