public class Forces {
  
  public double x;
  public double y;
 
  public Forces(double x, double y) {
    this.x = x;
    this.y = y;
  }
  
}
