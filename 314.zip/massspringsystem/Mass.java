import java.util.ArrayList;

public class Mass {
  
  public ArrayList<Spring> springs;
  public ArrayList<Damper> dampers;
  public double nextX;
  public double nextY;
  public double x;
  public double y;
  public double vx;
  public double vy;
  public boolean isWall;
  public double dt;
  public double mass;
  public boolean isTracker;
  public boolean gravity = false;
  public ArrayList<Forces> forces;
  public int r;
  public int g;
  public int b;
  boolean isselected;
  
  public Mass() {
    springs = new ArrayList<Spring>();
    dampers = new ArrayList<Damper>();
    forces = new ArrayList<Forces>();
    isWall = false;
    mass = 1;
    dt = 0.1;
    vx = 0;
    vy = 0;
    isTracker = false;
    r = 255;
    g = 0;
    b = 0;
    isselected = false;
  }


public void addForce(Forces f) {
   forces.add(f); 
}
  
  public void addSpring(Spring spring) {
    springs.add(spring); 
  }
  
  public void addDamper(Damper damper) {
    dampers.add(damper); 
  }
  
  
  public void updateNext() {
    double xForces = 0;
    double yForces = 0;
    double[] array = {0.0, 0.0};
    for (Spring s : springs) {
      array = s.computeForce(this);
      xForces = xForces + array[0];
      yForces = yForces + array[1];
    }
    for (Damper d : dampers) {
      array = d.computeForce(this);
      xForces = xForces + array[0];
      yForces = yForces + array[1];
    }
    
    for (Forces f: forces) {
      xForces = xForces + f.x;
      yForces = yForces + f.y;
    }
    forces.clear();
    
    double xacc = xForces/mass;
    double yacc = yForces/mass;
    if (gravity) {
      yacc = yacc + 0.1; 
    }
    
    double xPrev = x - dt*vx;
    double yPrev = y - dt*vy;
    
    nextX = xacc*dt*dt + 2*x - xPrev;
    nextY = yacc*dt*dt + 2*y - yPrev;
  }
  
    public void update() {
      if (isWall) {
        
      } else {
        vx = (nextX - x)/dt;
        vy = (nextY - y)/dt;
        x = nextX;
        y = nextY;
      }
  }
  
}
