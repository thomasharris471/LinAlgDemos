import java.util.ArrayList;
import java.util.Random;

public class Controller {
  
  ArrayList<Mass> masses;
  ArrayList<Mass> walls;
  int columns = 200;
  int rows = 200;
  double scale = 10;
  double dt = 0.1;
  int prunesize = 10000;
  boolean gravity = false;
  double bombsize = 100;
  double dampconstant = 1;
  double sconstant = 49;
  boolean tunnel = false;
     int wallwidth = 2;
  int trackerrow = 1;
  int trackercolumn = (int) columns/2;
  
  ArrayList<Double> tracking;
  Random rand;
  
  
  public Mass getTracker() {
    return gridMass(trackerrow, trackercolumn); 
  }

  
  public Controller() {
    tracking = new ArrayList<Double>();
    masses = new ArrayList<Mass>();
    walls = new ArrayList<Mass>();
          rand = new Random();
    for (int j = 0; j < columns; j++) {
      Mass m = new Mass();
      m.isWall = true;
      m.y = rows*scale;
      m.x = j*scale;


      walls.add(m);
    }
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < columns; j++) {
        Mass m = new Mass();
        m.x = j*scale;
        m.y = i*scale;
        m.dt = dt;
        m.mass = rand.nextDouble() + 1;
        m.mass = 2;
        m.gravity = gravity;
        masses.add(m);
        
      }
    }
    for (int i = 0; i < rows-1; i++) {
      for (int j = 1; j < columns-1; j++) {
        Spring s= new Spring();
        s.springConstant = sconstant;
        Spring s2= new Spring();
        s2.springConstant = 10*rand.nextDouble() + 15;
        Spring s3= new Spring();
        s3.springConstant = 10*rand.nextDouble() + 15;
   //     connectViaSpring(gridMass(i, j),gridMass(i+1, j+1), s2);
   //     connectViaSpring(gridMass(i, j),gridMass(i+1, j-1), s3);
        connectViaSpring(gridMass(i, j),gridMass(i+1, j), s);
        Damper d = new Damper();
        d.damperConstant = dampconstant;
        connectViaDamper(gridMass(i, j),gridMass(i+1, j), d);
      }
    }
    for (int j = 0; j < columns-1; j++) {
      for (int i = 0; i < rows; i++) {
        Spring s= new Spring();
        s.springConstant = sconstant;
        connectViaSpring(gridMass(i, j), gridMass(i, j+1), s);
        Damper d = new Damper();
        d.damperConstant = dampconstant;
        connectViaDamper(gridMass(i, j),gridMass(i, j+1), d);
      }
    }
    for (int j = 0; j < columns; j++) {
      Spring s = new Spring();
      s.springConstant = sconstant;
      connectViaSpring(gridMass(rows-1, j), walls.get(j), s);
      Damper d = new Damper();
      d.damperConstant = dampconstant;
     connectViaDamper(gridMass(rows-1, j),walls.get(j), d);
    }
    for (int i = 0; i < columns; i++) {
      gridMass(0, i).isWall = true; 
       gridMass(0, i).y =  gridMass(0, i).y - 20; 
    }
    for (int i = 0; i < rows; i++) {
      gridMass(i, 0).isWall = true; 
     gridMass(i, columns-1).isWall = true; 
     gridMass(i, columns-1).x = gridMass(i, columns-1).x + 50;
    }
    gridMass(trackerrow, trackercolumn).isTracker = true;
    for (int i = 0; i < rows; i++) {
      gridMass(i, 10).isWall = true; 
    }
    gridMass((int) rows/2, 10).isWall = false;
     gridMass((int) rows/2 + 1, 10).isWall = false;
     
     gridMass((int) rows/2 + 20, 10).isWall = false;
     gridMass((int) rows/2 + 20 + 1, 10).isWall = false;
    /*
    
    for (int j = (int) columns/3; j < (int) 2*columns/3+1; j++) {
      gridMass((int) rows/3, j).isWall = true;
      gridMass((int) 2*rows/3, j).isWall = true;
    }
     for (int i = (int) rows/3; i < (int) 2*rows/3+1; i++) {
      gridMass((int) i, (int) columns/3).isWall = true;
       gridMass((int) i, (int) 2*columns/3).isWall = true;
    }
    for (int i = (int) 2*rows/3; i < rows; i++) {
      gridMass((int) i, (int) columns/2).isWall = true;
    }
    for (int i = 0; i < (int) columns/3; i++) {
      gridMass((int) rows/3, i).isWall = true; 
       
    }
    //for (int i = (int) columns/9; i < (int) 2*columns/9; i++) {
    //  gridMass((int) rows/3, i).isWall = false; 
   // }
    gridMass((int) rows/3, (int) (columns)/6).isWall = false; 
    */
   // for (Mass m : masses) {
   //   if (rand.nextDouble() > 0.99) {
   //     m.isWall = true; 
   //   }
  //  }
  for (int i = (int) 3*rows/4; i < rows; i++) {
     for (int j = 0; j < columns; j++) {
        gridMass(i, j).mass = 20; 
        gridMass(i,j).r = 0;
        gridMass(i,j).g = 0;
        gridMass(i,j).b = 255;
     }
    }
    
   // for (int i = (int) 2*rows/5; i < 2*rows/5+10; i++) {
  //     gridMass(i, columns-1).isWall = false;
   // }

   if (tunnel) {
   for (int j = 0; j < 145 ; j++) {
      gridMass(j , trackercolumn-wallwidth).isWall = true;
      gridMass(j , trackercolumn+wallwidth).isWall = true;
   }
   for (int j = trackercolumn-wallwidth; j < trackercolumn+wallwidth; j++) {
     gridMass(144, j).isWall= true; 
   }
   }
    /*
    for (int i = (int) 2*rows/5+1; i < 2*rows/5+10-1; i++) {
       for (int j = columns-1; j < columns-1 + 100; j++) {
          Mass m = new Mass();
          m.x = j*scale;
          m.y = i*scale;
          m.dt = dt;
          m.mass = rand.nextDouble() + 1;
          m.mass = 2;
          m.gravity = gravity;
          masses.add(m);
      }
    }
    */
    
  }
  
  public void update() {
    double ty = getTracker().y;
    tracking.add(ty);
    if (tracking.size() > prunesize) {
      System.out.println("banana");
      for (int j = 0; j < (int) prunesize/2; j++) {
        tracking.remove(0); 
      }
    }
    for (Mass m : masses) {
      m.updateNext(); 
    }
    for (Mass m : masses) {
      m.update(); 
    }
  }
  
  public Mass gridMass(int i, int j) {
    return masses.get(i*columns + j);
  }
  
  public void connectViaSpring(Mass m1, Mass m2, Spring s) {
    m1.addSpring(s);
    m2.addSpring(s);
    s.leftMass = m1;
    s.rightMass = m2;
  }
  
  public void connectViaDamper(Mass m1, Mass m2, Damper s) {
    m1.addDamper(s);
    m2.addDamper(s);
    s.leftMass = m1;
    s.rightMass = m2;
  }
  
  public void bomb(int i, int j) {

    gridMass(i,j+1).x = gridMass(i,j+1).x+bombsize;
    gridMass(i,j-1).x = gridMass(i,j-1).x-bombsize;
    gridMass(i,j+1).vx = bombsize;
    gridMass(i,j-1).vx = -bombsize;
    gridMass(i+1,j).y = gridMass(i+1,j).y+bombsize;
     gridMass(i-1,j).y = gridMass(i-1,j).y-bombsize;
      gridMass(i+1,j).vy = bombsize;
    gridMass(i-1,j).vy = -bombsize;
    
  }
  
    public void earthquake(int i, int j) {

    gridMass(i+1,j).y = gridMass(i+1,j).y+bombsize;
    gridMass(i,j).y = gridMass(i,j).y+bombsize;
    gridMass(i-1,j).y = gridMass(i-1,j).y+bombsize;
    
    gridMass(i+1,j+1).y = gridMass(i+1,j+1).y-bombsize;
    gridMass(i,j+1).y = gridMass(i,j+1).y-bombsize;
    gridMass(i-1,j+1).y = gridMass(i-1,j+1).y-bombsize;

    
  }
  
   public void vibration(int i, int j, double frequency, double time, double amplitude) {

     //double xForce = 
    // gridMass(i+1,j).add(
    Forces f1 = new Forces(0, -amplitude*(Math.sin(frequency*time)));
    Forces f2 = new Forces(0, amplitude*(Math.sin(frequency*time)));
    Forces f3 = new Forces(amplitude*(Math.sin(frequency*time)), 0);
    Forces f4 = new Forces(-amplitude*(Math.sin(frequency*time)), 0);
   gridMass(i+1,j).addForce(f1);
    gridMass(i-1,j).addForce(f2);
    gridMass(i,j+1).addForce(f3);
    gridMass(i,j-1).addForce(f4);
    
    
 //   gridMass(i+1,j).y = gridMass(i+1,j).y-amplitude*(Math.sin(frequency*time)+1);
 //   gridMass(i-1,j).y = gridMass(i-1,j).y+amplitude*(Math.sin(frequency*time)+1);
    
 //   gridMass(i,j+1).x = gridMass(i,j+1).x+amplitude*(Math.sin(frequency*time)+1);
  //  gridMass(i,j-1).x = gridMass(i,j-1).x-amplitude*(Math.sin(frequency*time)+1);
    

    
  }
  
}
