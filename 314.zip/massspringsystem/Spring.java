public class Spring {
  
  public Mass leftMass;
  public Mass rightMass;
  public double springConstant;
  public double restLength;
  
  public Spring() {
    springConstant = 20;
    restLength = 1;
  }
  
  public double[] computeForce(Mass whichMass) {
     double x0 = leftMass.x;
     double x1 = rightMass.x;
     double y0 = leftMass.y;
     double y1 = rightMass.y;
     
     double force = springConstant*(Math.sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0)) - restLength);
     double[] direction = {0,0};
     double xVal = (x0 - x1)/Math.sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0));
     double yVal = (y0 - y1)/Math.sqrt((x1-x0)*(x1-x0) + (y1-y0)*(y1-y0));
     if (whichMass == leftMass) {
       direction[0] = -force*xVal;
       direction[1] = -force*yVal;
     } else if(whichMass == rightMass) {
       direction[0] = force*xVal;
       direction[1] = force*yVal;
     } else {
        
     }
     return direction;
  }

  
}
